# -*- coding: utf-8 -*-
import htmlentitydefs
import json
import os.path as path
import re
import urllib
import urllib2

from kodiswift import Plugin, xbmc, ListItem

plugin = Plugin()
__addondir__ = xbmc.translatePath(plugin.addon.getAddonInfo('path'))
__resdir__ = path.join(__addondir__, 'resources')
__imgsearch__ = path.join(__resdir__, 'search.png')


def smart_unicode(s):
    if not s:
        return ''
    try:
        if not isinstance(s, basestring):
            if hasattr(s, '__unicode__'):
                s = unicode(s)
            else:
                s = unicode(str(s), 'UTF-8')
        elif not isinstance(s, unicode):
            s = unicode(s, 'UTF-8')
    except:
        if not isinstance(s, basestring):
            if hasattr(s, '__unicode__'):
                s = unicode(s)
            else:
                s = unicode(str(s), 'ISO-8859-1')
        elif not isinstance(s, unicode):
            s = unicode(s, 'ISO-8859-1')
    return s


def clean1(s):  # remove &XXX;
    if not s:
        return ''
    for name, value in htmlentitydefs.entitydefs.iteritems():
        if u'&' in s:
            s = s.replace(u'&' + name + u';', value)
    return s;


def clean2(s):  # remove \\uXXX
    pat = re.compile(r'\\u(....)')

    def sub(mo):
        return unichr(int(mo.group(1), 16))

    return pat.sub(sub, smart_unicode(s))


def clean3(s):  # remove &#XXX;
    pat = re.compile(r'&#(\d+);')

    def sub(mo):
        return unichr(int(mo.group(1)))

    return decode(pat.sub(sub, smart_unicode(s)))


def decode(s):
    if not s:
        return ''
    try:
        dic = htmlentitydefs.name2codepoint
        for key in dic.keys():
            entity = '&' + key + ';'
            s = s.replace(entity, unichr(dic[key]))
    except:
        pass
    return s


def makeVideoItems(itemlist, sitename=None):
    """
    Takes a list of dict's returned from the API and looks for the specific fields to build XBMC ListItem for each item
    :param itemlist:
    :return: List of dict(Label, Label2, Icon, Thumb, Path) items created for each dict returned from the API
    """
    litems = []
    allitems = []
    vitem = dict()
    vid = dict()
    item = dict()
    SKIP = False
    try:
        for vitem in itemlist:
            assert isinstance(vitem, dict)
            lbl = ''
            lbl2 = ''
            vcats = ''
            tagstring = ''
            plotstring = ''
            thumb = ''
            thumb2 = ''
            thumbslist = []
            length = ''
            lengthnum = ''
            vidid = ''
            vurl = ''
            views = ''
            vtitle = ''
            pubdate = ''
            reldate = ''
            SITE = ''
            if vitem.has_key('video'):
                vid = vitem.get('video')
            else:
                vid = vitem
            if vid is not None:
                try:
                    assert isinstance(vid, dict)
                    if vid.has_key('url'):
                        vurl = vid.get('url')
                    elif vid.has_key('link'):
                        vurl = vid.get('link')
                    elif vid.has_key('embed'):
                        vurl = vid.get('embed')
                    if vurl.find('xtube') != -1 or vurl.find('spankwire') != -1:
                        SKIP = True
                    SITE = vurl.replace('http://', '').partition('/')[0].split('.', 1)[1].replace('.com', '').title()
                    if vid.has_key('default_thumb'):
                        thumb = vid.get('default_thumb')
                    if vid.has_key('thumbnail'):
                        if thumb == '':
                            thumb = vid.get('thumbnail')
                        else:
                            thumb2 = vid.get('thumbnail')
                    if vid.has_key('thumb'):
                        if thumb == '':
                            thumb = vid.get('thumb')
                        else:
                            thumb2 = vid.get('thumb')
                    if vid.has_key('views'):
                        views = vid.get('views')
                    if vid.has_key('duration'):
                        length = vid.get('duration')
                    elif vid.has_key('size'):
                        length = vid.get('size').get('seconds')
                    if vid.has_key('id'):
                        vidid = vid.get('id')
                    elif vid.has_key('video_id'):
                        vidid = vid.get('video_id')
                    else:
                        vidid = vurl.rsplit('-', 1)[0]
                    if vid.has_key('title'):
                        vtitle = unicode(vid.get('title').title()).encode('ascii', 'ignore')
                    elif vitem.has_key('title'):
                        vtitle = vitem.get('title').title()
                    if vid.has_key('publish_date'):
                        pubdate = vid.get('publish_date')
                    elif vitem.has_key('publish_date'):
                        pubdate = vitem.get('publish_date')
                    if len(pubdate) > 0:
                        reldate = pubdate
                        pubdate = pubdate.split(' ', 1)[0]
                        pubdate = pubdate.replace('2016-', '')
                    vtitle = vtitle.replace('"', '')
                    vtitle = vtitle.replace("'", '')
                    lbl = vtitle.replace('&', 'and')
                    if vid.has_key('category'):
                        vcats = vid.get('category')
                        plotstring = vcats
                    elif vid.has_key('categories'):  # and not SKIP:
                        vcatlist = vid.get('categories')
                        vcats = str(vcatlist[:]).replace("category':", "")
                        plotstring = vcats.replace("{", "").replace("}", "").replace("u'", "").replace("'", "").strip(
                            '[]')
                    if vid.has_key("tags"):  # and not SKIP:
                        tagslist = vid.get("tags")
                        tagstring = str(tagslist[:]).replace("tag_name':", "").replace("tag':", "").replace("{",
                                                                                                            "").replace(
                            "}", "").replace("u'", "").replace("'", "").strip('[]')
                    if length == "00:00:00":
                        length = ''
                    elif len(length) > 0:
                        if length.find(':') == -1:
                            lenint = 0
                            seconds = int(length)
                            m, s = divmod(seconds, 60)
                            h, m = divmod(m, 60)
                            length = "%02d:%02d" % (m, s)
                            if h > 0: length = "%d:%02d:%02d" % (h, m, s)
                            lengthnum = length
                        else:
                            lengthnum = length
                            if length.startswith("00:00:"):
                                length = length.replace("00:00:", "") + "s"
                    if vid.has_key('thumbs'):
                        thumbsdict = vid.get('thumbs')
                        if thumbsdict[0].has_key('src'):
                            for i in thumbsdict:
                                thumbslist.append(i.get('src'))
                            thumb2 = thumbslist[-1]
                    elif vitem.has_key('thumbs'):
                        if vitem.get('thumbs').has_key('big'):
                            thumbslist = vitem.get('thumbs').get('big')
                            thumb2 = thumbslist[-1]
                except:
                    xbmc.log("*****ERROR MAKING VIDEO ITEM")
                if sitename is not None:
                    lbl += '\n{0} [COLOR yellow]{1}[/COLOR] [COLOR red]{2}[/COLOR]'.format(length, pubdate, SITE)
                elif SITE.lower().find("motherless") != -1:
                    lbl += ' [COLOR yellow]{0}[/COLOR]'.format(length)
                else:
                    lbl += '\n{0} [COLOR red]{1}[/COLOR] {2}'.format(length, pubdate, SITE)
                lbl = lbl.replace(' Com', '')
                lbl2 = "{0} * {1} * ID:{2}".format(plotstring, tagstring, vidid)
                vpath = plugin.url_for(play, title=vtitle, video=thumb, url=vurl)
                xli = ListItem(label=lbl, label2=lbl2, icon=thumb, thumbnail=thumb, path=vpath)
                xli.thumbnail = thumb
                xli.icon = thumb
                xli.poster = thumb
                xli.add_context_menu_items(
                    [('Download', 'RunPlugin("{0}")'.format(plugin.url_for(download, name=lbl, url=vurl)),)])
                infolbl = {'Runtime': lengthnum, 'Year': reldate, 'Studio': SITE, 'Genre': plotstring,
                           'Plot': tagstring, 'Rating': views}
                xli.set_info(info_type='video', info_labels=infolbl)
                if thumb2 != '':
                    if len(thumbslist) > 0:
                        xli.poster = thumbslist[0]
                        xli.thumbnail = thumbslist[1]
                        xli.icon = thumbslist[2]
                        xli.set_art({'fanart': thumbslist[-1]})
                    else:
                        xli.poster = thumb2
                        xli.set_art({'fanart': thumb2})
                else:
                    xli.set_art({'fanart': thumb})
                xli.playable = True
                litems.append(xli)
    except:
        xbmc.log("ERROR MAKINGVIDEOITEMS: {0}\n".format(repr(vitem)))
    litems.sort(key=lambda litems: litems.label)
    return litems


def parseVideosUrl(url):
    """
    Sends request to API and returns the JSON object as a List of Dicts which is parsed into XBMC ListItems by makeVideoItems
    :param url:
    :return: List(dict())
    """
    obj = dict()
    if url.find('xtube.com') != -1 or url.find('motherless') != -1: obj = []
    headers = {}
    headers.update({
                       'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36'})
    headers.update({
                       'Accept': 'application/json,text/x-json,text/x-javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'})
    headers.update({'Accept-Language': 'en-US,en;q=0.5'})
    req = urllib2.Request(url=url, data=None, headers=headers)
    resp = urllib2.urlopen(req).read()
    obj = json.loads(resp)
    if url.find('xtube.com') != -1 or url.find('motherless') != -1: return obj
    try:
        if len(obj.keys()) == 1:
            return obj.get(obj.keys()[0])
        elif obj.has_key('videos'):
            return obj.get('videos')
        else:
            return obj
    except:
        xbmc.log("*** PARSE ERROR \n{0}".format(resp))
        return None


def readjson():
    dictallcats = dict()
    try:
        txt = file(path.join(__addondir__, 'spankwire.json'), 'r').read()
        dictallcats = json.loads(txt)  # dictallcats = json.JSONDecoder().decode(txt)
        if len(dictallcats.keys) == 1:
            return dictallcats.get(dictallcats.get(dictallcats.keys[0]))
        else:
            return dictallcats
    except:
        return []


def savejson(obj, filename):
    try:
        f = file(filename, 'w')
        txt = json.dump(obj, f)
        f.close()
    except:
        pass


def make_catitems(dictallcats):
    # SPANKWIRE specific code first version that created category listing for gay spankwire site.
    urlbase = "http://www.spankwire.com/api/HubTrafficApiCall?"
    caturl = urlbase + "data=getCategoriesList&output=json&segment=gay"
    catvidsurl = urlbase + "data=searchVideos&output=json&thumbsize=small&count=100&segment=gay&search=&tags=&category={0}"
    searchurl = urlbase + "data=searchVideos&output=json&thumbsize=small&count=100&segment=gay&search={0}&tags=&category="
    thumbcaturl = "http://cdn2.static.spankwire.com/images/category/Gay/{0}.jpg"
    listofcats = dictallcats.get(dictallcats.keys()[0])
    catvidslistitems = []
    for cat in listofcats:
        catname = cat.get('category')
        caturl = catvidsurl.format(catname)
        thumb = thumbcaturl.format(catname.replace(' ', '').replace('/', '').replace('&', ''))
        viditem = dict(label=catname, icon=thumb, thumb=thumb,
                       path=plugin.url_for(category, catname=catname, url=caturl))
        viditem.setdefault(viditem.keys()[0])
        catvidslistitems.append(viditem)
    return catvidslistitems


def catlist_tube8(isGay=True):
    urlapi = "http://api.tube8.com/api.php?action=getcategorieslist&output=json"
    turl = getAPIURLS('tube8').replace('search=&', 'search={0}&')
    turl = turl.replace('search=gay&', 'search={0}+gay&')
    resp = ''
    litems = []
    allitems = []
    catlist = []
    resp = urllib2.urlopen(urlapi).read()
    obj = json.loads(unicode(resp).decode('ascii'))
    try:
        if isGay:
            catlist = obj.get("gay")
        else:
            catlist = obj.get("straight")
        for catname in catlist:
            cname = catname.title()
            cimg = 'DefaultFolder.png'
            curl = turl.format(catname)
            cpath = plugin.url_for(site, sitename='tube8', section='index', url=curl)
            citem = dict(label=cname, icon=cimg, thumb=cimg, path=cpath)
            citem.setdefault(citem.keys()[0])
            allitems.append(citem)
        litems = sorted(allitems, key=lambda allitems: allitems['label'])
    except:
        pass
    return litems


def catlist_xtube():
    urlapi = "http://www.xtube.com/webmaster/api.php?action=getCategoryList"
    gturl = getAPIURLS('xtube')
    gturl = gturl.replace('&category=&', '&category={0}&')
    resp = ''
    html = ''
    catlist = []
    litems = []
    allitems = []
    resp = urllib2.urlopen(urlapi).read()
    obj = json.loads(unicode(resp).decode('ascii'))
    try:
        assert isinstance(obj, list)
        for item in obj:
            assert isinstance(item, dict)
            catlist.append(item.values().pop())
        for catname in catlist:
            cimg = 'DefaultFolder.png'
            curl = gturl.format(urllib.quote_plus(catname))
            cpath = plugin.url_for(site, sitename='xtube', section='index', url=curl)
            citem = dict(label=catname.title(), icon=cimg, thumb=cimg, path=cpath)
            citem.setdefault(citem.keys()[0])
            allitems.append(citem)
        litems = sorted(allitems, key=lambda allitems: allitems['label'])
    except:
        pass
    return litems


def catlist_youporn():
    urlapi = "http://www.youporn.com/api/webmasters/categories/"
    gturl = getAPIURLS('youporn')
    gturl = gturl.replace('&category=&', '&category={0}&')
    resp = ''
    html = ''
    catlist = []
    litems = []
    allitems = []
    resp = urllib2.urlopen(urlapi).read()
    obj = json.loads(unicode(resp).decode('ascii'))
    try:
        assert isinstance(obj, list)
        for item in obj:
            assert isinstance(item, dict)
            catlist.append(item.values().pop())
        for catname in catlist:
            # assert isinstance(catname, dict)
            # cname = catname.get('category')
            cimg = 'DefaultFolder.png'
            curl = gturl.format(urllib.quote_plus(catname))
            cpath = plugin.url_for(site, sitename='youporn', section='index', url=curl)
            citem = dict(label=catname.title(), icon=cimg, thumb=cimg, path=cpath)
            citem.setdefault(citem.keys()[0])
            allitems.append(citem)
        litems = sorted(allitems, key=lambda allitems: allitems['label'])
    except:
        pass
    return litems


def catlist_gaytube():
    # urlhtml = "http://www.gaytube.com/c/abc?m=azl"
    # html = urllib2.urlopen(urlhtml).read()
    # Above is to try and scrape category pictures so defaultfolder doesn't have to be used but can't get a Regex to work
    urlapi = "http://api.redtube.com/?data=redtube.Categories.getCategoriesList&output=json"
    urlapi = "http://www.gaytube.com/api/webmasters/categories/"
    gturl = getAPIURLS('gaytube').replace('&category=', '&category={0}')
    resp = ''
    html = ''
    catlist = []
    litems = []
    allitems = []
    resp = urllib2.urlopen(urlapi).read()
    obj = json.loads(unicode(resp).decode('ascii'))
    catlist = obj.get('categories')
    try:
        for catname in catlist:
            assert isinstance(catname, dict)
            cname = catname.get('category')
            cimg = 'DefaultFolder.png'
            curl = gturl.format(urllib.quote_plus(cname))
            cpath = plugin.url_for(site, sitename='gaytube', section='index', url=curl)
            citem = dict(label=cname.title(), icon=cimg, thumb=cimg, path=cpath)
            citem.setdefault(citem.keys()[0])
            allitems.append(citem)
        litems = sorted(allitems, key=lambda allitems: allitems['label'])
    except:
        pass
    return litems


def catlist_pornhub():
    urlapi = "http://www.pornhub.com/webmasters/categories"
    gturl = getAPIURLS('pornhub')
    ISGAY = True
    if gturl.find('=gay') != -1:
        gturl = gturl.replace('&category=gay&', '&category={0}&')
    else:
        ISGAY = False
        gturl = gturl.replace('&category=&', '&category={0}&')
    resp = ''
    html = ''
    catlist = []
    litems = []
    allitems = []
    resp = urllib2.urlopen(urlapi).read()
    obj = json.loads(unicode(resp).decode('ascii'))
    catlist = obj.get('categories')
    try:
        for catname in catlist:
            assert isinstance(catname, dict)
            cname = catname.get('category')
            cimg = 'DefaultFolder.png'
            curl = gturl.format(urllib.quote_plus(cname))
            cpath = plugin.url_for(site, sitename='pornhub', section='index', url=curl)
            citem = dict(label=cname.title(), icon=cimg, thumb=cimg, path=cpath)
            citem.setdefault(citem.keys()[0])
            if ISGAY and cname.find('gay') != -1:
                allitems.append(citem)
            if not ISGAY and cname.find('gay') == -1:
                allitems.append(citem)
        litems = sorted(allitems, key=lambda allitems: allitems['label'])
    except:
        pass
    return litems


def catlist_redtube():
    urlapi = "http://api.redtube.com/?data=redtube.Categories.getCategoriesList&output=json"
    gturl = getAPIURLS('redtube').replace('&category=&', '&category={0}&')
    resp = ''
    html = ''
    catlist = []
    litems = []
    allitems = []
    resp = urllib2.urlopen(urlapi).read()
    obj = json.loads(unicode(resp).decode('ascii'))
    catlist = obj.get('categories')
    try:
        for catname in catlist:
            assert isinstance(catname, dict)
            cname = catname.get('category')
            cimg = 'DefaultFolder.png'
            curl = gturl.format(urllib.quote_plus(cname))
            cpath = plugin.url_for(site, sitename='redtube', section='index', url=curl)
            citem = dict(label=cname.title(), icon=cimg, thumb=cimg, path=cpath)
            citem.setdefault(citem.keys()[0])
            allitems.append(citem)
        litems = sorted(allitems, key=lambda allitems: allitems['label'])
    except:
        pass
    return litems


def groupslist_motherless():
    vitems = []
    litems = []
    allitems = []
    listofurls = groupurls_motherless()
    for url in listofurls:
        try:
            vitems = parseVideosUrl(url)
            litems = makeVideoItems(vitems)
            allitems.extend(litems)
        except:
            xbmc.log("Failed parsing URL {0}".format(url))
    allitems.sort(key=lambda allitems: allitems.label)
    return allitems


def groupurls_motherless():
    MOGROUPS2 = ['straight_men_having_fun_with_men', 'twinks', 'debbie_hearts_favorite_twinks', 'mmmmm_boys',
                 'selfshot_guys', 'boy_twink_ass', 'male_oral_sex_boys_18_', 'gay_incest', 'amateur_boys',
                 'naked_men_in_public', 'amateur_male_masturbation']
    MOGROUPS = ['amateur_boys', 'daddies___bros___bears_oh_my_', 'amateur_male_masturbation', 'naked_men_in_public',
                'twinks', 'debbie_hearts_favorite_twinks', 'straight_men_having_fun_with_men', 'men_gay_homosexuals',
                'real_hardcore_gay_group', 'selfshot_guys', 'boy_twink_ass', 'male_oral_sex_boys_18_',
                'nude_men_at_the_beach', 'gay_incest', 'father___son', '_gay_incest___family_fun_']
    burl = str(getAPIURLS(sitename='motherless'))
    grouplist = []
    for grp in MOGROUPS:
        grouplist.append(burl.format(grp))
    return grouplist


def getAPIURLS(sitename=None):
    """
    If a sitename is passes then just the URL to that sites API is returned if nothing is passed then a dictionary of Key=Sitename, Value=API URL is returned
    This function handles looking at the Plugin Settings to determine the Sorting/Ordering which defaults to NEWEST
    bugs still exist on ordering as dif API's use a dif word for other sortings but NEWEST works on all
    STR8 setting is checked and if it is enabled then the correct URL's are selected which doesn't specify segment=gay or gay in tags/search
    :param sitename:
    :return: URL of API for sitename specified or DICT(sitename: URL, sitename2: URL)
    """
    MOGROUPS = ['mmmmm_boys', 'amateur_boys', 'daddies___bros___bears_oh_my_', 'amateur_male_masturbation',
                'naked_men_in_public', 'twinks', 'debbie_hearts_favorite_twinks', 'straight_men_having_fun_with_men',
                'men_gay_homosexuals', 'real_hardcore_gay_group', 'selfshot_guys', 'boy_twink_ass',
                'male_oral_sex_boys_18_', 'nude_men_at_the_beach', 'gay_incest', 'father___son',
                '_gay_incest___family_fun_']
    b = "http://www."
    siteapis = dict(
        gaytube=b + "gaytube.com/api/webmasters/search/?ordering=newest&period=alltime&thumbsize=preview&count=250&page=1&search=&tags[]=&category=",
        pornhub=b + "pornhub.com/webmasters/search?id=44bc40f3bc04f65b7a35&category=gay&ordering=newest&tags[]=&search=&page=1&thumbsize=large",
        redtube="http://api.redtube.com/?data=redtube.Videos.searchVideos&output=json&thumbsize=big&ordering=newest&page=1&search=&tags[]=gay&category=&period=alltime",
        spankwire=b + "spankwire.com/api/HubTrafficApiCall?data=searchVideos&output=json&ordering=newest&page=1&segment=gay&count=100&search=&tags=gay&thumbsize=big",
        tube8="http://api.tube8.com/api.php?action=searchVideos&output=json&ordering=newest&search=gay&thumbsize=big&page=1&orientation=gay",
        xtube=b + "xtube.com/webmaster/api.php?action=getVideosBySearchParams&tags=&ordering=newest&thumbsize=400x300&fields=title,tags,duration,thumbnail,url,embed,categories&search=gay&category=&page=1&count=100",
        youporn=b + "youporn.com/api/webmasters/search?search=&page=1&ordering=newest&tags[]=gay&category=&thumbsize=big",
        motherless="http://motherless.com/feeds/groups/{0}/videos?page=1&format=json")
    urls_straight = dict(
        gaytube=b + "gaytube.com/api/webmasters/search/?ordering=newest&period=alltime&thumbsize=all&count=100&page=1&search=&tags[]=",
        pornhub=b + "pornhub.com/webmasters/search?id=44bc40f3bc04f65b7a35&category=&ordering=newest&tags[]=&search=&page=1&thumbsize=medium",
        redtube="http://api.redtube.com/?data=redtube.Videos.searchVideos&output=json&thumbsize=medium&ordering=newest&page=1&search=&tags[]=&category=&period=alltime",
        spankwire=b + "spankwire.com/api/HubTrafficApiCall?data=searchVideos&output=json&ordering=newest&page=1&segment=straight&count=100&search=&tags=&thumbsize=all",
        tube8="http://api.tube8.com/api.php?action=searchVideos&output=json&ordering=newest&search=&thumbsize=big&page=1&orientation=straight",
        xtube=b + "xtube.com/webmaster/api.php?action=getVideosBySearchParams&tags=&ordering=newest&thumbsize=400x300&fields=title,tags,duration,thumbnail,url,embed,categories&search=&category=&page=1&count=100",
        youporn=b + "youporn.com/api/webmasters/search?search=&page=1&ordering=newest&tags[]=&category=&thumbsize=medium",
        motherless="http://motherless.com/feeds/groups/{0}/videos?page=1&format=json")
    DOSTR8 = plugin.get_setting(key='dostr8')
    DOFILTER = plugin.get_setting(key='dofilter')
    if DOFILTER == 'true' or DOFILTER == True:
        DOFILTER = True
    else:
        DOFILTER = False
    MYTAGS = plugin.get_setting(key='tags').replace(',', '+')
    ORDERBY = plugin.get_setting(key='sortby')
    if DOSTR8 == True or DOSTR8 == 'true':
        DOSTR8 = True
        siteapis = urls_straight
    if ORDERBY != 'newest':
        urlstemp = siteapis
        tempdict = dict()
        for k, v in urlstemp.iteritems():
            url = v.replace('ordering=newest', 'ordering={0}'.format(ORDERBY))
            tempdict.update(k=url)
        siteapis = tempdict
    if DOFILTER and len(MYTAGS) > 0:
        urlstemp = siteapis
        tempdict = dict()
        if not DOSTR8:
            for k, v in urlstemp.iteritems():
                newurl = str(v).replace('&tags[]=gay&', '&tags[]=gay+{0}&'.format(MYTAGS))
                newurl = newurl.replace('&tags[]=&', '&tags[]={0}&'.format(MYTAGS))
                newurl = newurl.replace('&tags=&', '&tags={0}&'.format(MYTAGS))
                newurl = newurl.replace('&tags=gay&', '&tags=gay+{0}&'.format(MYTAGS))
                tempdict.update(k=newurl)
            siteapis.update(tempdict)
        else:
            for k, v in urlstemp.iteritems():
                newurl = str(v).replace('&tags[]=&', '&tags[]={0}&'.format(MYTAGS))
                newurl = newurl.replace('&tags=&', '&tags={0}&'.format(MYTAGS))
                tempdict.update(k=newurl)
            siteapis.update(tempdict)
    if sitename is None:
        return siteapis
    else:
        if siteapis.has_key(sitename):
            return siteapis.get(sitename)
        else:
            return siteapis


@plugin.route('/')
def index():
    """
    Index for plugin this just builds the main items for the site's linked to the SITEROOT destination
    :return: List of ListItems for Index of all sites
    """
    litems = []
    igayp = __imgsearch__.replace('search.', 'fgaypower.')
    igay = __imgsearch__.replace('search.', 'fgaytube.')
    iph = __imgsearch__.replace('search.', 'fpornhub.')
    irt = __imgsearch__.replace('search.', 'fredtube.')
    isw = __imgsearch__.replace('search.', 'fspankwire.')
    it8 = __imgsearch__.replace('search.', 'ftube8.')
    ixt = __imgsearch__.replace('search.', 'fxtube.')
    iyp = __imgsearch__.replace('search.', 'fyouporn.')
    pgay = plugin.url_for(siteroot, sitename="gaytube")
    pph = plugin.url_for(siteroot, sitename="pornhub")
    prt = plugin.url_for(siteroot, sitename="redtube")
    psw = plugin.url_for(siteroot, sitename="spankwire")
    pt8 = plugin.url_for(siteroot, sitename="tube8")
    pxt = plugin.url_for(siteroot, sitename="xtube")
    pyp = plugin.url_for(siteroot, sitename="youporn")

    DOSTR8 = plugin.get_setting(key='dostr8')
    if not (DOSTR8 == True or DOSTR8 == 'true'):
        # IF the STR8 Setting is turned on no point in including the GAYTUBE site as it's gay specific content only
        item = {'label': 'GayPower (FULL LENGTH)', 'icon': igayp, 'thumb': igayp,
                'path': plugin.url_for(gaypower, page=1)}
        item.setdefault(item.keys()[0])
        litems.append(item)
        item = {'label': 'Gaytube', 'icon': igay, 'thumb': igay, 'path': pgay}
        litems.append(item)
    item = {'label': 'Pornhub', 'icon': iph, 'thumb': iph, 'path': pph}
    litems.append(item)
    item = {'label': 'Redtube', 'icon': irt, 'thumb': irt, 'path': prt}
    litems.append(item)
    item = {'label': 'Spankwire', 'icon': isw, 'thumb': isw, 'path': psw}
    litems.append(item)
    item = {'label': 'Tube8', 'icon': it8, 'thumb': it8, 'path': pt8}
    litems.append(item)
    item = {'label': 'Xtube', 'icon': ixt, 'thumb': ixt, 'path': pxt}
    litems.append(item)
    item = {'label': 'YouPorn', 'icon': iyp, 'thumb': iyp, 'path': pyp}
    litems.append(item)

    allitems = []
    for li in litems:
        li.setdefault(li.keys()[0])
        allitems.append(li)
    litems = sorted(allitems, key=lambda allitems: allitems['label'])
    iml = __imgsearch__.replace('search.', 'fmotherless.')
    pml = plugin.url_for(site, section='index', sitename='motherless',
                         url='http://motherless.com/feeds/groups/amateur_male_masturbation/videos?format=json')
    item = {'label': 'Motherless', 'icon': iml, 'thumb': iml, 'path': pml}
    litems.append(item)
    itemsearch = {'label': 'Search All Sites', 'path': plugin.url_for(search), 'icon': __imgsearch__,
                  'thumb': __imgsearch__}
    itemsearch.setdefault(itemsearch.keys()[0])
    litems.append(itemsearch)
    itemstream = {'label': 'Play Flashx.TV URL', 'path': plugin.url_for(resolver), 'icon': 'DefaultFolder.png',
                  'thumb': 'DefaultFolder.png'}
    itemstream.setdefault(itemstream.keys()[0])
    litems.append(itemstream)
    DODEBUG = plugin.get_setting('debugon')
    if DODEBUG == True or DODEBUG == 'true':
        itemd = dict(label='DEBUG', icon='DefaultFolder.png', thumb='DefaultFolder.png',
                     path=plugin.url_for(debug, url='http://watchseries-online.la/category/the-rachel-maddow-show'))
        itemd.setdefault(itemd.keys()[0])
        litems.append(itemd)
    return litems


@plugin.route('/siteroot/<sitename>/')
def siteroot(sitename):
    """
    Calls the site() function but helps by figuring out base URL to pass one special instance exists with site Spankwire
    I have setup category and thumbnails but it's the only site and only on the GAY segment. I hope to expand
    the functionality to add a category section to the sites and bring up the sites category list for GAY/STR8 as well
    as including a global attempt at category similar to the global search where a category will run the API's search
    using the tags=Category where possible or just search=Category if a tags criteria is not in the API. Until then
    I have this static category listing for GAY content on spankwire which I saved as a JSON file. The API exposes
    Category's for most sites but doesn't include Thumbnails and sometimes doesn't expose dif category's for GAY/STR8
    so to make Thumbnails for Gay content I scraped the webpage and just found it easier to statically set these up.
    :param sitename:
    :return: ListItems for the Index of the site specified
    """
    litems = []
    siteurl = getAPIURLS(sitename=sitename)
    DOSTR8 = plugin.get_setting(key='dostr8')
    if sitename.lower() == "spankwire" and not (DOSTR8 == True or DOSTR8 == 'true'):
        isw = __imgsearch__.replace('search.', 'fspankwire.')
        item = {'label': 'Spankwire Gay Categories',
                'path': plugin.url_for(site, sitename='spankwire', section='category', url=siteurl), 'icon': isw,
                'thumb': isw}
        item.setdefault(item.keys()[0])
        litems = [item]
        litems.extend(site(sitename, 'index', siteurl))
    elif sitename.lower() == "gaytube":
        igt = __imgsearch__.replace('search.', 'fgaytube.')
        item = {'label': 'GayTube Categories',
                'path': plugin.url_for(site, sitename='gaytube', section='category', url=siteurl), 'icon': igt,
                'thumb': igt}
        item.setdefault(item.keys()[0])
        litems = [item]
        litems.extend(site(sitename, 'index', siteurl))
    elif sitename.lower() == "pornhub":
        igt = __imgsearch__.replace('search.', 'fpornhub.')
        item = {'label': 'PornHub Categories',
                'path': plugin.url_for(site, sitename='pornhub', section='category', url=siteurl), 'icon': igt,
                'thumb': igt}
        item.setdefault(item.keys()[0])
        litems = [item]
        litems.extend(site(sitename, 'index', siteurl))
    elif sitename.lower() == "redtube":
        igt = __imgsearch__.replace('search.', 'fredtube.')
        item = {'label': 'RedTube Categories',
                'path': plugin.url_for(site, sitename='redtube', section='category', url=siteurl), 'icon': igt,
                'thumb': igt}
        item.setdefault(item.keys()[0])
        litems = [item]
        litems.extend(site(sitename, 'index', siteurl))
    elif sitename.lower() == "xtube":
        igt = __imgsearch__.replace('search.', 'fxtube.')
        item = {'label': 'XTube Categories',
                'path': plugin.url_for(site, sitename='xtube', section='category', url=siteurl), 'icon': igt,
                'thumb': igt}
        item.setdefault(item.keys()[0])
        litems = [item]
        litems.extend(site(sitename, 'index', siteurl))
    elif sitename.lower() == "tube8":
        igt = __imgsearch__.replace('search.', 'ftube8.')
        item = {'label': 'Tube8 Categories',
                'path': plugin.url_for(site, sitename='tube8', section='category', url=siteurl), 'icon': igt,
                'thumb': igt}
        item.setdefault(item.keys()[0])
        litems = [item]
        litems.extend(site(sitename, 'index', siteurl))
    elif sitename.lower() == "youporn":
        igt = __imgsearch__.replace('search.', 'fyouporn.')
        item = {'label': 'YouPorn Categories',
                'path': plugin.url_for(site, sitename='youporn', section='category', url=siteurl), 'icon': igt,
                'thumb': igt}
        item.setdefault(item.keys()[0])
        litems = [item]
        litems.extend(site(sitename, 'index', siteurl))
    else:
        litems = site(sitename, 'index', siteurl)
    return litems


@plugin.route('/site/<sitename>/<section>/<url>/')
def site(sitename, section, url):
    """
    Main working function for the addon and handles Site specific calls to Search a site, Next Page, and Index.
    Index and Search sections call back into this section for Next Page support
    A shortcut helper SITEROOT simply calls this function for each site but looks up the correct URL to pass to section=Index
    :param sitename: Name of site to perform section actions on
    :param section: Index, Search, Next
    :param url: API URL for the section
    :return: Listitems for results plus a Search Site Item and Next Page Item
    """
    litems = []
    itemslist = []
    DOSTR8 = plugin.get_setting(key='dostr8')
    __imgnext__ = __imgsearch__.replace('search.png', 'next.png')
    siteurl = getAPIURLS(sitename=sitename)
    if siteurl.find('search=gay&') != -1:
        surl = siteurl.replace('search=gay&', 'search={0}+gay&')
    else:
        surl = siteurl.replace('search=', 'search={0}')
    itemsearch = {'label': 'Search {0}'.format(sitename.title()),
                  'path': plugin.url_for(site, sitename=sitename, section='search', url=surl), 'icon': __imgsearch__,
                  'thumb': __imgsearch__}
    itemsearch.setdefault(itemsearch.keys()[0])
    pagenum = 2
    if url.find('page=') != -1:
        pagestr = str(url.split('page=', 1)[1]).split('&', 1)[0]
        if pagestr is not None:
            pagenum = int(pagestr) + 1
        else:
            pagenum = 2
    pagenumcur = pagenum - 1
    if url.find('page=1') != -1:
        nurl = url.replace('page=1&', 'page=2&')
    elif url.find('page=') != -1:
        nurl = url.replace('page={0}&'.format(pagenumcur), 'page={0}&'.format(pagenum))
    else:
        nurl = url + '&page={0}'.format(pagenum)
    itemnext = {'label': 'Next --> {0}'.format(pagenum),
                'path': plugin.url_for(site, sitename=sitename, section='next', url=nurl), 'icon': __imgnext__,
                'thumb': __imgnext__}
    itemnext.setdefault(itemnext.keys()[0])

    if section.lower() == "index":
        if sitename.lower() == 'motherless':
            litems = groupslist_motherless()
        else:
            # Index was called so get the first page of a specific site and return items with a Search and Next added
            vitems = list()
            itemslist = parseVideosUrl(url)
            litems = makeVideoItems(itemslist)
            itemslist = litems
            itemslist.insert(0, itemsearch)
            itemslist.append(itemnext)
            litems = itemslist
    elif section.lower() == "next":
        # Provides support for viewing Next set of results/page and accessed from the itemnext ListItem added to Index/Search
        vitems = list()
        itemslist = parseVideosUrl(url)
        litems = makeVideoItems(itemslist)
        itemslist = litems
        itemslist.insert(0, itemsearch)
        itemslist.append(itemnext)
        litems = itemslist
    elif section.lower() == "category":
        if sitename.lower() == 'spankwire':
            txt = file(path.join(__addondir__, 'spankwire.json')).read()
            allitems = json.loads(txt)
            itemlist = allitems.get(allitems.keys()[0])
            allitems = sorted(itemlist, key=lambda itemlist: itemlist['label'])
            for li in allitems:
                assert isinstance(li, dict)
                # catpath = plugin.url_for(category, catname=li.get('label'), url=li.get('path'))
                catpath = plugin.url_for(site, sitename='spankwire', section='index', url=li.get('path'))
                li.update(path=catpath)
                li.setdefault(li.keys()[0])
                litems.append(li)
        elif sitename.lower() == 'gaytube':
            litems = catlist_gaytube()
        elif sitename.lower() == 'pornhub':
            litems = catlist_pornhub()
        elif sitename.lower() == 'redtube':
            litems = catlist_redtube()
        elif sitename.lower() == 'xtube':
            litems = catlist_xtube()
        elif sitename.lower() == 'youporn':
            litems = catlist_youporn()
        elif sitename.lower() == 'tube8':
            if not (DOSTR8 == True or DOSTR8 == 'true'):
                litems = catlist_tube8(isGay=True)
            else:
                litems = catlist_tube8(isGay=False)
    elif section.lower() == "search":
        # Perform a search of the specific site and return results and a next page item - NOT a global multisite search
        searchtxt = ''
        try:
            searchtxt = plugin.get_setting('lastsearch')
        except:
            searchtxt = ''
        searchtxt = plugin.keyboard(searchtxt, 'Search {0}'.format(sitename.title()), False)
        searchquery = searchtxt.replace(' ', '+')
        plugin.set_setting(key='lastsearch', val=searchtxt)
        surl = surl.format(searchquery)
        itemslist = parseVideosUrl(surl)
        litems = makeVideoItems(itemslist)
        itemslist = litems
        itemslist.insert(0, itemsearch)
        nurl = surl.replace('page=1&', 'page=2&')
        itemnext = {'label': 'Next {0} --> {1}'.format(searchtxt, pagenum),
                    'path': plugin.url_for(site, sitename=sitename, section='next', url=nurl),
                    'icon': __imgnext__, 'thumb': __imgnext__}
        itemnext.setdefault(itemnext.keys()[0])
        itemslist.append(itemnext)
        litems = itemslist
    else:
        itemslist = parseVideosUrl(url)
        litems = makeVideoItems(itemslist)
        litems.append(itemnext)
    plugin.set_content('movies')
    return litems


@plugin.route('/gaypower/<page>')
def gaypower(page=1):
    boardurl = 'http://gaypower.org/index.php?page=Board&boardID=59&pageNo=' + page
    threadurl = 'http://gaypower.org/index.php?page=Thread&postID={0}'
    __imgnext__ = __imgsearch__.replace('search.png', 'next.png')
    page = int(page) + 1
    npath = plugin.url_for(gaypower, page=page)
    itemnext = {'label': 'Next --> {0}'.format(page), 'path': npath, 'icon': __imgnext__, 'thumb': __imgnext__}
    itemnext.setdefault(itemnext.keys()[0])
    bhtml = ''
    for p in range(1, 4):
        boardurl = "http://gaypower.org/index.php?page=Board&boardID=59&pageNo={0}".format(p)
        bhtml += urllib2.urlopen(boardurl).read()
    # bhtml = urllib2.urlopen(boardurl).read()
    recol = 'class="columnTopic" title="(.+?)".+?<a href="(.+?)">(.+?)</a>'
    reflashx = re.compile('(http://www.flashx.tv\/[^\"\s]*).')
    rethumb = re.compile('(http.+jpg)[\s\S]')
    vids = re.compile(recol, re.S).findall(bhtml)
    litems = []
    allitems = []
    thumb = 'DefaultFolder.png'
    if len(vids) > 0:
        try:
            for img, link, title in vids:
                if img.find('flashx.tv') != -1:
                    vurl = reflashx.findall(img)
                    imgmatch = rethumb.findall(img)
                    if len(imgmatch) > 0:
                        thumb = imgmatch.pop()
                    else:
                        thumb = 'DefaultFolder.png'
                    if len(vurl) > 0:
                        try:
                            vidurl = vurl[0]
                            vidurl = vidurl.replace('/embed-', '/')
                            vidurl = vidurl.rpartition('-')[0]
                            if not str(vidurl).endswith('.html'):
                                vidurl = vidurl + '.html'
                            vpath = plugin.url_for(play, title=title, video=thumb, url=vidurl)
                            # item = dict(label=title, label2=link, icon=thumb, thumb=thumb, path=vpath)
                            # item.setdefault(item.keys()[0])
                            item = ListItem(label=title, label2=link, icon=thumb, thumbnail=thumb, path=vpath)
                            item.playable = True
                            item.thumbnail = thumb
                            item.icon = thumb
                            item.add_context_menu_items([('Download', 'RunPlugin("{0}")'.format(
                                plugin.url_for(download, name=title, url=vidurl)),)])
                            allitems.append(item)
                        except:
                            xbmc.log("Error Resolving URL for Flashx ListItem")
            litems = sorted(allitems, key=lambda allitems: allitems.label)
            # litems = sorted(allitems, key=lambda allitems: allitems['label'])
        except:
            xbmc.log("Problem converting page to listitems")
    # litems.append(itemnext)
    # No Next page as only 4 pages of results so I load them all at the same time and sort them and list them
    return litems


@plugin.route('/resolver')
def resolver():
    litems = []
    url = ''
    cimg = 'DefaultFolder.png'
    try:
        url = plugin.keyboard(default='', heading='Video Page URL')
        if url != "":
            plugin.redirect(plugin.url_for(play(title='FlashX', video=cimg, url=url)))
        else:
            plugin.redirect(plugin.url_for(index))
    except:
        pass
    #return []


@plugin.route('/debug/<url>')
def debug(url):
    litems = []
    trmsimg = 'http://watchseries-online.la/wp-content/uploads/2016/01/181561-g.jpg'
    allinimg = 'http://watchseries-online.la/wp-content/uploads/2016/02/282633-g3.jpg'
    trmsepurl = 'http://watchseries-online.la/episode/the-rachel-maddow-show-2016-0{0}-{1}'
    allinurl = 'http://watchseries-online.la/category/All-In-with-Chris-Hayes'
    allinepurl = 'http://watchseries-online.la/episode/all-in-with-chris-hayes-2016-0{0}-{1}'
    eplist = []
    if url == 'http://watchseries-online.la/category/the-rachel-maddow-show':
        month = 6
        day = 1
        for mnum in range(6, 9):
            for dnum in range(1, 31):
                dlink = allinepurl.format(mnum, dnum)
                tlink = trmsepurl.format(mnum, dnum)
                epdict = dict(label="Rachel Maddow {0}-{1}".format(mnum, dnum), icon=trmsimg,
                              thumb=trmsimg, path=plugin.url_for(debug, url=tlink))
                epdict.setdefault(epdict.keys()[0])
                eplist.append(epdict)
                epdict = dict(label="All In {0}-{1}".format(mnum, dnum), icon=allinimg, thumb=allinimg,
                              path=plugin.url_for(debug, url=dlink))
                epdict.setdefault(epdict.keys()[0])
                eplist.append(epdict)
        return eplist
        # phtml = urllib2.urlopen(url).read()
        # matches = re.compile('href="(.+\/episode\/the-rachel-maddow-show.+)".+\/span>(.+)</a>', re.DOTALL).findall(phtml)
        # if matches is not None:
        #    trmsvids = matches[0]
        #    for link,title in trmsvids:
        #        elink = plugin.url_for(debug, url=link)
        #        item = dict(label=title, icon=trmsimg, thumb=trmsimg, path=elink)
        #        item.setdefault(item.keys()[0])
        #        litems.append(item)
        # return litems
    else:
        try:
            import urlresolver
            if url != "":
                headers = {}
                headers.update({
                                   'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36'})
                headers.update({'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'})
                headers.update({'Accept-Language': 'en-US,en;q=0.5'})
                req = urllib2.Request(url=url, data=None, headers=headers)
                phtml = urllib2.urlopen(req).read()
                # req = BaseRequest(cookie_file=xbmc.translatePath('profile://addon_data/plugin.video.hubgay/cookies.lwp'))
                # phtml = req.getSource(url, form_data='', referer='http://watchseries-online.la/')
                xbmc.log(phtml)
                reflashx = re.compile('(http://www.flashx.tv\/[^\"\s]*).')
                matches = reflashx.findall(phtml)
                litems = []
                if matches is not None:
                    for link in matches:
                        outstr = "LINKS {0} - {1}".format(link, url)
                        xbmc.log(outstr)
                        xbmc.executebuiltin('Notify("{0}")'.format(outstr))
                        litems.append(play(title='link', vide='DefaultFolder.png', url=link))
        except:
            pass
        return litems


@plugin.route('/play/<title>/<video>/<url>')
def play(title, video, url):
    """
    Play attempts to scrape the video's page and find the actual video file to play. This is still buggy but seems to work on
    a lot of the sites but not all the time so any help on this function working better would be appreciated. I pass in the
    title of the movie and the video tags the Thumbnail which I use to create a proper ListItem with the scrapped MP4 url
    :param title: Video Title to play passed to XBMC in a new ListItem object with resolved URL of video scraped from url
    :param video: Thumbnail URL of the video used as the icon and thumbnail for ListItem to play
    :param url: URL of the embed/video page to scrape for the real playable video file
    :return: ListItem of video with path = scraped url of the MP4/Video file hopefully
    """
    resolved = None
    mediaurl = None
    vidhtml = ''
    vidurl = ''
    vli = None
    try:
        if url.lower().find('flashx') != -1:
            import urlresolver
            resolved = ''
            host = urlresolver.HostedMediaFile(url)
            if host:
                resolver = urlresolver.resolve(url)
                resolved = resolver
            else:
                resolved = host
            vli = ListItem(label=title, label2=url, icon=video, thumbnail=video, path=resolved)
            vli.playable = True
            # vli.add_stream_info(stream_type='video', stream_values={'Codec': 'avc'})
            # xbmc.executebuiltin('PlayMedia("{0}")'.format(resolved))
            plugin.play_video(vli)
            return [vli]
            #return plugin.set_resolved_url(resolved)
            # return plugin.set_resolved_url(plugin.play_video(vli))
    except:
        xbmc.log("\n****Failed to use URL Resolver to play video {0}".format(url))
    matches = None
    try:
        vidhtml = urllib2.urlopen(url).read()
        if url.find('youporn') != -1:
            matches = re.compile('(http.+?mp4.+?[^"])"', re.DOTALL + re.S).findall(vidhtml)
        elif url.find('xtube') != -1:
            matches = re.compile('"(http.+?mp4.+?[^"])"', re.DOTALL + re.S).findall(vidhtml)
        elif url.find('gaytube') != -1:
            matches = re.compile('p="(http.+?mp4.+?[^"])"', re.DOTALL + re.S).findall(vidhtml)
            matches2 = re.compile('flashvars.quality_[0-9]+p="(http.+?)";', re.DOTALL + re.S).findall(vidhtml)
        elif url.find('pornhub') != -1:
            matches = re.compile('(http.+?mp4.ipa=.+?[^\'])\'', re.DOTALL + re.S).findall(vidhtml)
        elif url.find('redtube') != -1:
            matches = re.compile('="(http.+?mp4.+?[^"])"', re.DOTALL + re.S).findall(vidhtml)
        elif url.find('spankwire') != -1 or url.find('motherless') != -1:
            matches = re.compile("'(http.+?mp4.+?[^'])'", re.DOTALL + re.S).findall(vidhtml)
    except:
        xbmc.log("\n****Failed to Resolve VID URL from REGEXes {0}\n{1}".format(url, str(repr(matches))))
    try:
        if matches is not None:
            vidurl = urllib.unquote_plus(matches[0])
            xbmc.log("***FLASHVAR RE FOUND VIDEO {0}\n{1}".format(vidurl, title))
            vli = ListItem(label=title, label2=url, icon=video, thumbnail=video, path=vidurl)
            vli.playable = True
            vli.thumbnail = video
            vli.icon = video
            plugin.play_video(vli)
            return [vli]
            #xbmc.executebuiltin('PlayMedia("{0}")'.format(vidurl))
            #return plugin.set_resolved_url(vidurl)
    except:
        xbmc.log("\n***FLASHVAR SCRAPE FAILED TO PLAY SCRAPED SOURCE {0}".format(url))
    try:
        import YDStreamExtractor
        info = YDStreamExtractor.getVideoInfo(url)
        vidurl = info.streamURL()  # YDStreamExtractor.handleDownload(info, bg=True)
        if vidurl is not None and len(vidurl) > 0:
            if vidurl.find('|') != -1: vidurl = vidurl.partition('|')[0]
            xbmc.log("***YTDL FOUND VIDEO {0}\n{1}".format(vidurl, title))
            vli = ListItem(label=title, label2=url, icon=video, thumbnail=video, path=vidurl)
            vli.playable = True
            vli.thumbnail = video
            vli.icon = video
            plugin.play_video(vli)
            return [vli]
            #xbmc.executebuiltin('PlayMedia("{0}")'.format(vidurl))
            #return plugin.set_resolved_url(vidurl)
    except:
        xbmc.log("\n***FAILED TO USE YOUTUBEDL {0}".format(url))
    return plugin.set_resolved_url(vidurl)


@plugin.route('/download/<name>/<url>')
def download(name='', url=''):
    resolved = None
    hosturl = url[url.find('://') + 3:url.find('.com/')]  # .split('/',1)[0]
    if not hosturl in getAPIURLS().keys():
        try:
            import urlresolver
            host = urlresolver.HostedMediaFile(url)
            if host:
                resolver = urlresolver.resolve(url)
                resolved = resolver
        except:
            pass
    else:
        try:
            vidhtml = urllib2.urlopen(url).read()
            matches = re.compile('(http.+?mp4[^"]*)"').findall(vidhtml)
            if matches is not None:
                resolved = matches[0].replace('\/', '/')
            else:
                matches = re.compile('(http://[^"<]+?.mp4[^"<]+?)"', re.I + re.M + re.S + re.U).findall(vidhtml)
                if matches is not None:
                    resolved = matches[0]
                else:
                    matches = re.compile('(http://[^"<]+?.flv[^"<]+?)"', re.I + re.M + re.S + re.U).findall(vidhtml)
                    if matches is not None:
                        resolved = matches[0]
        except:
            pass
    try:
        import YDStreamExtractor
        if resolved is None:
            info = YDStreamExtractor.getVideoInfo(url)
            resolved = info.streamURL()
            if resolved is not None:
                if resolved.find('|') != -1: resolved = resolved.partition('|')[0]
            else:
                xbmc.log("\n*****Failed to resolve URL to downloadable video {0}".format(url))
                return None
        savepath = ''
        savepath = plugin.get_setting('downloadpath')
        info = YDStreamExtractor.getVideoInfo(resolved)
        if savepath == '':
            result = YDStreamExtractor.handleDownload(info, bg=True)
        else:
            result = YDStreamExtractor.handleDownload(info, bg=True, path=savepath)
        xbmc.log("\n***DOWNLOAD {0} from {1}\n***RESULT {2}\n".format(url, resolved, str(repr(result))))
    except:
        pass
    return None


def olddownload(resolved, name):
    url = resolved
    try:
        if url is not None and len(url) > 0:
            name = name.partition('[')[0]
            name = name.replace(' ', '-')
            ext = url.rpartition('.')[2]
            nameClean = name + '.' + ext[0:3]
            savepath = ''
            savepath = plugin.get_setting('downloadpath')
            if savepath == '':
                savepath = path.expanduser('~/Downloads/')
            regex = re.compile('[^a-zA-Z0-9_\.\- ]+')
            nameClean = regex.sub('_', nameClean).strip()
            downloader = None
            try:
                import SimpleDownloader
                downloader = SimpleDownloader.SimpleDownloader()
            except:
                xbmc.log("FAILED TO DOWNLOAD {0}".format(url))
            dparams = {}
            dparams["Title"] = name
            dparams["url"] = url
            dparams["download_path"] = savepath
            downloader.download(nameClean, dparams)
        else:
            xbmc.log("***FAILED TO DOWNLOAD {0} to {1}\n".format(url, name))
    except:
        xbmc.log("ERROR DOWNLOADING WITH SIMPLE DOWNLOADER {0}".format(url))
    try:
        import YDStreamExtractor
        info = YDStreamExtractor.getVideoInfo(url)
        YDStreamExtractor.handleDownload(info, bg=True)
        return None
    except:
        xbmc.log("FAILED TO DOWNLOAD WITH YOUTUBEDL {0}".format(url))


@plugin.route('/category/<catname>/<url>/')
def category(catname, url):
    """
    Old Category handler only specific to Spankwire Gay at this time as Category's are not supported for all sites yet
    :param catname:
    :param url:
    :return:
    """
    caturl = "http://www.spankwire.com/api/HubTrafficApiCall?data=getCategoriesList&output=json&segment=gay"
    thumbcaturl = "http://cdn2.static.spankwire.com/images/category/Gay/{0}.jpg"
    if url is None: url = caturl.format(catname)
    itemslist = parseVideosUrl(url)
    litems = makeVideoItems(itemslist)
    return litems


@plugin.route('/search/')
def search():
    """
    Pop's up a keyboard with the default value read from settings with whatever was typed last time.
    Loops over the list of JSON API's putting the search word into the URL and making ListItems for each site before
    combining all results and sorting them
    """
    searchtxt = ''
    searchtxt = plugin.get_setting('lastsearch')
    searchtxt = plugin.keyboard(searchtxt, 'Search All Sites', False)
    searchquery = searchtxt.replace(' ', '+')
    plugin.set_setting(key='lastsearch', val=searchtxt)
    litems = []
    allitems = []
    itemslist = []
    DOSTR8 = plugin.get_setting(key='dostr8')
    __imgnext__ = __imgsearch__.replace('search.png', 'next.png')
    siteurls = getAPIURLS()
    siteurls.pop('motherless')
    for k, v in siteurls.iteritems():
        siteurl = v
        if siteurl.find('search=gay&') != -1:
            surl = siteurl.replace('search=gay&', 'search={0}+gay&')
        else:
            surl = siteurl.replace('search=', 'search={0}')
        searchurl = surl.format(searchquery)
        itemslist = parseVideosUrl(searchurl)
        allitems.extend(makeVideoItems(itemslist, sitename=k.title()))
    litems = sorted(allitems, key=lambda allitems: allitems.label)
    plugin.set_content('movies')
    return litems


if __name__ == '__main__':
    plugin.run()
    viewmode = int(plugin.get_setting('viewmode'))
    if viewmode is None: viewmode = 500
    plugin.set_view_mode(viewmode)
